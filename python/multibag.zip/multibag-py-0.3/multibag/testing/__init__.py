"""
a subpackage with utilities useful for testing multibag applications.  This 
includes a module (mkdata) for creating simulated data that can be turned into 
bags and split.  
"""
